package com.demo;

public interface ICompute {
	
	public int add(int a, int b);

}
