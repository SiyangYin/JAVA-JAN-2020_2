/**
 * 
 */
package com.marlabs.model;

/**
 * @author Nanda
 *
 */
public abstract class Observer {
	Employee employee;
	public abstract void update();
}
