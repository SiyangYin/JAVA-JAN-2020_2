1. Change DB conf in resources/database.properties
2. Create table from the given .sql file
3. Run Main.java program
